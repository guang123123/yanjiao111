// index.js
Page({
  onWebViewMessage(event) {
    const message = event.detail.data;
    if (message === 'jumpToNativePage') {
      wx.navigateToMiniProgram({
        appId: 'wx0ebba09eb6c99e50',
        path: '/pages/about/about',
        success(res) {
          console.log('跳转到小程序原生页面成功', res);
        },
        fail(res) {
          console.error('跳转到小程序原生页面失败', res);
        }
      })
    }
  }
})